primo esercizio da fare per casa
